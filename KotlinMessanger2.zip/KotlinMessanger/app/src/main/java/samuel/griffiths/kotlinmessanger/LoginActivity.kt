package samuel.griffiths.kotlinmessanger

import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.util.Log
import kotlinx.android.synthetic.main.activity_login.*

class LoginActivity: AppCompatActivity(){

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_login)

        login_btn_login.setOnClickListener {
            val email = email_tv_login.text.toString()
            val password = password_tv_login.text.toString()

            Log.d("LoginActivity", "Attempt to login with Email: ${email} and Password: ${password}")
        }

        back_to_registration_tv_login.setOnClickListener {
            finish()
        }
    }

}